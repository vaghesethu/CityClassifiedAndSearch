package com.virtusa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CitySearchDAO {
	String url="jdbc:mysql://localhost:3306/CitySearch";
	String uname="root";
	String pass="abc";
	public Connection getConnection()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,uname,pass);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public Connection check(String userName,String password) 
	{		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,uname,pass);
			String query="select * from user where userName=? and password=? ";
			 PreparedStatement st=con.prepareStatement(query);
			 st.setString(1, userName);
			 st.setString(2, password);
			 ResultSet rs=st.executeQuery();
			 if(rs.next()){
				 return con;
			 }	 
			 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
