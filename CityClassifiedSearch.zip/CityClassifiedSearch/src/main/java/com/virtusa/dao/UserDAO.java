package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.bean.User;
public class UserDAO {
	
	public static void addUser(Connection con, User user) throws SQLException {
			String query = "Insert into User (userName,userEmail,password,userType) values(?,?,?,?);"; 
	        PreparedStatement pstm = con.prepareStatement(query);
	        pstm.setString(1,user.getUserName());
	        pstm.setString(2,user.getUserEmail());
	        pstm.setString(3,user.getPassword());
	        pstm.setString(4,user.getUserType());        
	        pstm.executeUpdate();
		}
		public static User findUser(Connection con,String userName,String password) throws SQLException {
			String query = "Select * from User where userEmail=? and password=BINARY? "; 
			if(con!=null) {
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setString(1, userName);
				pstm.setString(2, password);
				ResultSet rs = pstm.executeQuery();
				User user=new User();
				if (rs.next()) {
					int userId=rs.getInt("userId");
					String userEmail=rs.getString("userEmail");
					String userType=rs.getString("userType");
					user.setUserId(userId);
					user.setUserName(userName);
					user.setPassword(password);
					user.setUserEmail(userEmail);
					user.setUserType(userType);
					return user;
					}
			}
			return null;
		}
		public static boolean findEmail(Connection con,String userEmail) throws SQLException {
			String query = "Select count(*) from User where userEmail=?"; 
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, userEmail);
			ResultSet rs = pstm.executeQuery();
			int count=0;
			if (rs.next()){
				count = rs.getInt(1);
				System.out.print(count);
			}
			if(count==0) {
				return true;
			}
			return false;
		}
}
