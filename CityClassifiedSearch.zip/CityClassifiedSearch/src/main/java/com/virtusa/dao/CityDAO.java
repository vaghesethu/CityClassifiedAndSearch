package com.virtusa.dao;

public class CityDAO {

}
