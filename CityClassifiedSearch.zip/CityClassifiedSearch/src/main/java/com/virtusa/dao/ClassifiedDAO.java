package com.virtusa.dao;

public class ClassifiedDAO {

}
