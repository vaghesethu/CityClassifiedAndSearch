package com.virtusa.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.bean.User;

public class DBUtil {
	public static void addUser(Connection con, User user) throws SQLException {
		String query = "Insert into User values(?,?,?,?,?);"; 
        PreparedStatement pstm = con.prepareStatement(query);
        pstm.setInt(1, user.getUserId());
        pstm.setString(2, user.getUserName());
        pstm.setString(3,user.getUserEmail());
        pstm.setString(4,user.getPassword());
        pstm.setString(5,user.getUserType());        
        pstm.executeUpdate();
	}
	public static User findUser(Connection con,String userName,String password) throws SQLException {
		String query = "Select * from User where userName=? and password=BINARY? "; 
		if(con!=null) {
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, userName);
			pstm.setString(2, password);
			ResultSet rs = pstm.executeQuery();
			User user=new User();
			if (rs.next()) {
				int userId=rs.getInt("userId");
				String userEmail=rs.getString("userEmail");
				String userType=rs.getString("userType");
				user.setUserId(userId);
				user.setUserName(userName);
				user.setPassword(password);
				user.setUserEmail(userEmail);
				user.setUserType(userType);
				return user;
				}
		}
		return null;
	}
}
