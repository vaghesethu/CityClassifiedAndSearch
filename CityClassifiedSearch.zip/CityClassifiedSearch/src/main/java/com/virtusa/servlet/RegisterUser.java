package com.virtusa.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.User;
import com.virtusa.dao.UserDAO;
import com.virtusa.util.DBUtil;

@WebServlet("/Register")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterUser() {
        super();
    }
    static int userId=1;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String userEmail=request.getParameter("userEmail");
		String password=request.getParameter("password");
		DBUtil db=new DBUtil();
		Connection con=null;
		User user= new User();
		user.setUserName(userName);
		user.setUserEmail(userEmail);
		user.setPassword(password);
		user.setUserType("user");
		try{
			con=db.getConnection();
			if(UserDAO.findEmail(con, userEmail)) {
				UserDAO.addUser(con, user);
			}else {
				request.setAttribute("error","User already exists");
				request.getRequestDispatcher("/register.jsp").forward(request, response);
			}
							
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
		/***call SendEmail()***/
		response.sendRedirect("emailverification.jsp");
	}

}
