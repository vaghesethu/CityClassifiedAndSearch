package com.virtusa.servlet;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.User;
import com.virtusa.dao.CitySearchDAO;
import com.virtusa.util.DBUtil;

@WebServlet("/Register")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterUser() {
        super();
    }
    static int userId=1;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String userEmail=request.getParameter("userEmail");
		String password=request.getParameter("password");
		User user= new User();
		user.setUserId(userId);
		user.setUserName(userName);
		user.setUserEmail(userEmail);
		user.setPassword(password);
		user.setUserType("user");
		userId++;
		CitySearchDAO dao=new CitySearchDAO();
		try {
			Connection con=dao.getConnection();
			DBUtil.addUser(con, user);
		}catch(Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("login.jsp");
	}

}
