package com.virtusa.bean;

public class City {
	public int cityId;
	public String cityName;
	public String category;
	public String categoryName;
	public String address;
	public String mobile;
	public String email;
	public int getCityId() {
		return cityId;
	}
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getName() {
		return categoryName;
	}
	public void setName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "City [cityId=" + cityId + ", cityName=" + cityName + ", category=" + category + ", categoryName=" + categoryName
				+ ", address=" + address + ", Mobile=" + mobile + ", email=" + email + "]";
	}	
}
