package com.virtusa.bean;

public class Classified {
	public int cId;
	public String cName;
	public String cCategory;
	public String cDescription;
	public String cAddress;
	public String cCity;
	public String cMobile;
	public String cEmail;
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcCategory() {
		return cCategory;
	}
	public void setcCategory(String cCategory) {
		this.cCategory = cCategory;
	}
	public String getcDescription() {
		return cDescription;
	}
	public void setcDescription(String cDescription) {
		this.cDescription = cDescription;
	}
	public String getcAddress() {
		return cAddress;
	}
	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}
	public String getcCity() {
		return cCity;
	}
	public void setcCity(String cCity) {
		this.cCity = cCity;
	}
	public String getcMobile() {
		return cMobile;
	}
	public void setcMobile(String cMobile) {
		this.cMobile = cMobile;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	@Override
	public String toString() {
		return "Classified [cId=" + cId + ", cName=" + cName + ", cCategory=" + cCategory + ", cDescription="
				+ cDescription + ", cAddress=" + cAddress + ", cCity=" + cCity + ", cMobile=" + cMobile + ", cEmail="
				+ cEmail + "]";
	}
	
}
