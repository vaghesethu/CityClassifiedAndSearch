package com.virtusa.bean;

public class User {
	public int userId;
	public String userName;
	public String userEmail;
	public String password;
	public String userType;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ", password="
				+ password + ", userType=" + userType + "]";
	}
}
/*MySql
userId int not null auto_increment,
userName varchar(20),
userEmail varchar(50),
password varchar(10),
userType varchar(5),
primary key(userId)
);
*/
